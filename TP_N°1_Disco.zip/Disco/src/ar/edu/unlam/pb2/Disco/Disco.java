package ar.edu.unlam.pb2.Disco;

public class Disco {

	// ATRIBUTOS
	private Double radioInteriorDeDisco;
	private Double radioExteriorDeDisco;
	private Double perimetroInteriorDeDisco;
	private Double perimetroExteriorDeDisco;

	// COSTRUCTOR
	public Disco(Double radioInteriorDeDisco, Double radioExteriorDeDisco) {
		
		if (radioInteriorDeDisco > radioExteriorDeDisco){
			this.setRadioInteriorDeDisco(radioExteriorDeDisco);
			this.setRadioExteriorDeDisco(radioInteriorDeDisco);
		}else if (radioInteriorDeDisco < radioExteriorDeDisco){
				this.setRadioInteriorDeDisco(radioInteriorDeDisco);
				this.setRadioExteriorDeDisco(radioExteriorDeDisco);
			}
	}

	// METODOS:
	
	
	// CALCULAR PERIMETRO INTERIOR

	public double perimetroInteriorDeDisco(Double radioInterior) {
		this.setRadioInteriorDeDisco(radioInterior);
		return (2 * Math.PI * radioInterior);
	}

	// CALCULAR PERIMETRO EXTERIOR
	public double perimetroExteriorDeDisco(Double radioExterior) {
		this.setRadioExteriorDeDisco(radioExterior);
		return (2 * Math.PI * radioExterior);
	}

	// CALCULAR SUPERFICIE DEL DISCO
	public double superficieDeDisco(Double radioInterior, Double radioExterior ) {
		this.setRadioInteriorDeDisco(radioInterior);
		this.setRadioExteriorDeDisco(radioExterior);
		Double superficieInterior = Math.PI * radioInterior * radioInterior;
		Double superficieExterior = Math.PI * radioExterior * radioExterior;
		return (superficieExterior - superficieInterior);
	}

	
	
	public Double getRadioInteriorDeDisco() {
		return radioInteriorDeDisco;
	}

	public void setRadioInteriorDeDisco(Double radioInteriorDeDisco) {
		this.radioInteriorDeDisco = radioInteriorDeDisco;
	}

	public Double getRadioExteriorDeDisco() {
		return radioExteriorDeDisco;
	}

	public void setRadioExteriorDeDisco(Double radioExteriorDeDisco) {
		this.radioExteriorDeDisco = radioExteriorDeDisco;
	}

	public Double getPerimetroInteriorDeDisco() {
		return perimetroInteriorDeDisco;
	}

	public void setPerimetroInteriorDeDisco(Double perimetroInteriorDeDisco) {
		this.perimetroInteriorDeDisco = perimetroInteriorDeDisco;
	}

	public Double getPerimetroExteriorDeDisco() {
		return perimetroExteriorDeDisco;
	}

	public void setPerimetroExteriorDeDisco(Double perimetroExteriorDeDisco) {
		this.perimetroExteriorDeDisco = perimetroExteriorDeDisco;
	}
		

	
}
