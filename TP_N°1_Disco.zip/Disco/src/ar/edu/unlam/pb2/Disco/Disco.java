package ar.edu.unlam.pb2.Disco;

public class Disco {

	// ATRIBUTOS
	private Double radioInteriorDeDisco;
	private Double radioExteriorDeDisco;
	private Double perimetroInteriorDeDisco;
	private Double perimetroExteriorDeDisco;

	// COSTRUCTOR
	public Disco(Double radioInteriorDeDisco, Double radioExteriorDeDisco) {
		
		if (radioInteriorDeDisco > radioExteriorDeDisco){
			this.radioInteriorDeDisco = radioExteriorDeDisco;
			this.radioExteriorDeDisco = radioInteriorDeDisco;
		}else if (radioInteriorDeDisco < radioExteriorDeDisco){
				this.radioInteriorDeDisco = radioInteriorDeDisco;
				this.radioExteriorDeDisco = radioExteriorDeDisco;
			}
	}

	// METODOS:
	
	
	// CALCULAR PERIMETRO INTERIOR

	public double perimetroInteriorDeDisco(Double radioInterior) {
		this.radioInteriorDeDisco = radioInterior;
		return (2 * Math.PI * radioInterior);
	}

	// CALCULAR PERIMETRO EXTERIOR
	public double perimetroExteriorDeDisco(Double radioExterior) {
		this.radioExteriorDeDisco = radioExterior;
		return (2 * Math.PI * radioExterior);
	}

	// CALCULAR SUPERFICIE DEL DISCO
	public double superficieDeDisco(Double radioInterior, Double radioExterior ) {
		this.radioInteriorDeDisco = radioInterior;
		this.radioExteriorDeDisco = radioExterior;
		Double superficieInterior = Math.PI * radioInterior * radioInterior;
		Double superficieExterior = Math.PI * radioExterior * radioExterior;
		return (superficieExterior - superficieInterior);
	}
		

	
}
