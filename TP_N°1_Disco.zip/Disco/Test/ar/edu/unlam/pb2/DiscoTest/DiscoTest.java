package ar.edu.unlam.pb2.DiscoTest;

import org.junit.Assert;
import org.junit.Test;

import ar.edu.unlam.pb2.Disco.Disco;


public class DiscoTest {
	
@Test
	
	public void queLosValoresDelosPerimetroSeanCorrectos(){
		//preparacion
		Double radioInteriorTest = 1.00;
		Double radioExteriorTest = 2.00;
		
		Double perimetroInteriorEsperado = 6.28;
		Double perimetroExteriorEsperado = 12.56;
		
	//ejecucion
		Disco miDisco = new Disco(radioInteriorTest, radioExteriorTest);
		
		Double perimetroInteriorObtenido = miDisco.perimetroInteriorDeDisco(radioInteriorTest);
		Double perimetroExteriorObtenido = miDisco.perimetroExteriorDeDisco(radioExteriorTest);
		
		
	//constratacion
	
	Assert.assertEquals(perimetroInteriorEsperado, perimetroInteriorObtenido, 0.01);
	Assert.assertEquals(perimetroExteriorEsperado, perimetroExteriorObtenido, 0.01);
	}
	
	
@Test 	
	public void queLaSuperficieCalculadaSeaCorrecta(){
		//PREPARACION
		Double radioInteriorTest = 1.00;
		Double radioExteriorTest = 2.00;

		Double superficieEsperada = 9.42;
		
		
		//EJECUCION					
		Disco miDisco = new Disco (radioInteriorTest, radioExteriorTest);
		Double superficieObtenida = miDisco.superficieDeDisco(radioInteriorTest, radioExteriorTest);
		
		//CONSTRATACION

		Assert.assertEquals(superficieEsperada, superficieObtenida, 0.01);
	}

}
